--------------------------------------------------------
--  Arquivo criado - Sexta-feira-Novembro-19-2021   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table PERFIL_NAVEGACAO_COLHEITA
--------------------------------------------------------

  CREATE TABLE "RM86353"."PERFIL_NAVEGACAO_COLHEITA" 
   (	"ID_PERFIL_NAVEGACAO" NUMBER(10,0), 
	"DATA_INSERCAO" TIMESTAMP (6), 
	"ID_USUARIO" NUMBER(10,0)
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  TABLESPACE "TBSPC_ALUNOS" ;
--------------------------------------------------------
--  DDL for Index SYS_C001452172
--------------------------------------------------------

  CREATE UNIQUE INDEX "RM86353"."SYS_C001452172" ON "RM86353"."PERFIL_NAVEGACAO_COLHEITA" ("ID_PERFIL_NAVEGACAO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "TBSPC_ALUNOS" ;
--------------------------------------------------------
--  Constraints for Table PERFIL_NAVEGACAO_COLHEITA
--------------------------------------------------------

  ALTER TABLE "RM86353"."PERFIL_NAVEGACAO_COLHEITA" MODIFY ("ID_PERFIL_NAVEGACAO" NOT NULL ENABLE);
  ALTER TABLE "RM86353"."PERFIL_NAVEGACAO_COLHEITA" ADD PRIMARY KEY ("ID_PERFIL_NAVEGACAO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "TBSPC_ALUNOS"  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table PERFIL_NAVEGACAO_COLHEITA
--------------------------------------------------------

  ALTER TABLE "RM86353"."PERFIL_NAVEGACAO_COLHEITA" ADD CONSTRAINT "FKT3OLC6HTW6AGRUIHENF1J0G5V" FOREIGN KEY ("ID_USUARIO")
	  REFERENCES "RM86353"."TB_USUARIO_COLHEITA" ("ID_USUARIO") ENABLE;
