--------------------------------------------------------
--  Arquivo criado - Sexta-feira-Novembro-19-2021   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table TB_PRODUTO_COLHEITA
--------------------------------------------------------

  CREATE TABLE "RM86353"."TB_PRODUTO_COLHEITA" 
   (	"ID_PRODUTO" NUMBER(10,0), 
	"CATEGORIA" VARCHAR2(255 CHAR), 
	"DT_VALIDADE" TIMESTAMP (6), 
	"NOME" VARCHAR2(255 CHAR), 
	"PRECO" FLOAT(126), 
	"ID_USUARIO" NUMBER(10,0)
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  TABLESPACE "TBSPC_ALUNOS" ;
--------------------------------------------------------
--  DDL for Index SYS_C001452174
--------------------------------------------------------

  CREATE UNIQUE INDEX "RM86353"."SYS_C001452174" ON "RM86353"."TB_PRODUTO_COLHEITA" ("ID_PRODUTO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "TBSPC_ALUNOS" ;
--------------------------------------------------------
--  Constraints for Table TB_PRODUTO_COLHEITA
--------------------------------------------------------

  ALTER TABLE "RM86353"."TB_PRODUTO_COLHEITA" MODIFY ("ID_PRODUTO" NOT NULL ENABLE);
  ALTER TABLE "RM86353"."TB_PRODUTO_COLHEITA" ADD PRIMARY KEY ("ID_PRODUTO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  TABLESPACE "TBSPC_ALUNOS"  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table TB_PRODUTO_COLHEITA
--------------------------------------------------------

  ALTER TABLE "RM86353"."TB_PRODUTO_COLHEITA" ADD CONSTRAINT "FKIVTTK8RLWD3VNIFSTVVCH4TEU" FOREIGN KEY ("ID_USUARIO")
	  REFERENCES "RM86353"."TB_USUARIO_COLHEITA" ("ID_USUARIO") ENABLE;
